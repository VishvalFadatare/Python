# -*- coding: utf-8 -*-
"""
Created on Mon Nov 11 12:09:34 2024

@author: vishv
"""

import matplotlib.pyplot as plt
import numpy as np

xpoints = np.array([1, 8])
ypoints = np.array([3, 10])

plt.plot(xpoints, ypoints)
plt.show()