# -*- coding: utf-8 -*-
"""
Created on Fri Oct 25 14:32:19 2024

@author: vishv
"""

import numpy as np 

arr=np.array([1,2,3,4,5])
print(arr)
print(arr.ndim)