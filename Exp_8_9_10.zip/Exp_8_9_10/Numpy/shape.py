# -*- coding: utf-8 -*-
"""
Created on Mon Nov 11 11:29:27 2024

@author: vishv
"""

import numpy as np

arr = np.array([[1, 2, 3, 4], [5, 6, 7, 8],[11,22,33,44]])

print(arr.shape)