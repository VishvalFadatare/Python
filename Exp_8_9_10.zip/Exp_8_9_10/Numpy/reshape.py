# -*- coding: utf-8 -*-
"""
Created on Mon Nov 11 11:34:39 2024

@author: vishv
"""

import numpy as np

arr = np.array([1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12])

arr1 = arr.reshape(4, 3)

print(arr1)