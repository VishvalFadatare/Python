# -*- coding: utf-8 -*-
"""
Created on Mon Nov 11 11:58:57 2024

@author: vishv
"""

import pandas as pd

data = pd.read_csv('data.csv')
print(data)
